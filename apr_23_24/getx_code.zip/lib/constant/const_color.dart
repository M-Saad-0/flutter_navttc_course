import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ConstColor {
  static var primaryColor = const Color(0xffffffff).obs;
  static var blackColor = Color.fromARGB(255, 71, 11, 11).obs;
  static var blueColor = const Color(0xffffffff).obs;
}
