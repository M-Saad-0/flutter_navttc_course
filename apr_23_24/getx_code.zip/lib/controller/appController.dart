import 'package:get/get.dart';

class AppController extends GetxController {
  var isFav = true.obs;
}
